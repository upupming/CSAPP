void callee(){
}

void caller(){
    callee();
}
