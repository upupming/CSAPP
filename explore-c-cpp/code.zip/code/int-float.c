void int_float(){
    int i_a = 45, i_b;
    float f_a, f_b = 3.14;

    f_a = i_a;
    i_b = f_b;
}
