void int_long(){
    int i_a = -1, i_b;
    long l_a, l_b = 6;

    l_a = i_a;
    i_b = l_b;
}
