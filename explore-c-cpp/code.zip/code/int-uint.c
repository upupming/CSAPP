void int_uint(){
    int i_a = 8, i_b;
    unsigned int ui_a, ui_b = 7;
   
    ui_a = i_a;
    i_b = ui_b;
}
