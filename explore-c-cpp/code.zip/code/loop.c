int loop(){
    int i, sum;
    for(i=0; i<5; i++)
        sum += i;
    return sum;
}
